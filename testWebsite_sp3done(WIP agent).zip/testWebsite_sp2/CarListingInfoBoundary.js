document.addEventListener('DOMContentLoaded', () => {
    new CarListingBoundary();
});

class CarListingBoundary {
	constructor() {
		 this.init()
	}
	
	init() {
		this.loadCarListingInfo(id)
		this.checkBuyerShortlist(id)		
	}
	
	loadCarListingInfo(id) {
		fetch('CarListingInfoFetchController.php?id=' + id)
		.then(response => response.json())
		.then(data => {
			// Put in the fetched content
			const item = data[0];
			$('#car_name').text(item.car_name);
			$('#price').text('$' + parseFloat(item.price).toFixed(2));
			$('#regDate').text(item.regDate);
			$('#noOfOwners').text(item.noOfOwners);
			$('#plate_no').text(item.plate_no);
			$('#vehType').text(item.vehType);
			$('#description').text(item.description);
			$('#seller_name').text(item.seller_name);
			$('#agent_name').text(item.agent_name);
			
			// Put in new image source
			$('.main-image').attr('src', item.imagePath);	

			//Retrieve seller and agent's names
			const sellerName = $('#seller_name').text();
			const agentName = $('#agent_name').text();
			
			//Run the function to retrieve their contact info
			this.loadSellerContactInfo(sellerName);
			this.loadAgentContactInfo(agentName);
		})
		.catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
		});
	}
	
	loadAgentContactInfo(username) {
		fetch('UserContactInfoFetchController.php?username=' + username)
		.then(response => response.json())
		.then(data => {
			$('#agent_contactno').text(data.contactno);
			$('#agent_email').text(data.email);
		})
		.catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
		});
	}
	
	loadSellerContactInfo(username) {
		fetch('UserContactInfoFetchController.php?username=' + username)
		.then(response => response.json())
		.then(data => {
			$('#seller_contactno').text(data.contactno);
			$('#seller_email').text(data.email);
		})
		.catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
		});
	}
	
	checkBuyerShortlist(id) {
		fetch('CheckBuyerShortlistController.php?id=' + id + '&username=' + username)
		.then(response => response.json())
		.then(isShortlisted => {
			if(isShortlisted == false) {
				$('#removeFromShortlist').hide();
				$('#addToShortlist').show();
			} else {
				$('#addToShortlist').hide();
				$('#removeFromShortlist').show();				
			}
		})
		.catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
		});
	}
}