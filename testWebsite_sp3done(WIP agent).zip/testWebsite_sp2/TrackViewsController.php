<?php
require_once 'UsedCarListing.php';
header('Content-Type: application/json');


if($_SERVER['REQUEST_METHOD'] === "GET") {
	TrackViewsController::updateViewTracker($_GET['action'], $_GET['viewsListingId']);
}

class TrackViewsController {
	
	public static function updateViewTracker($action, $id) {	
		$trackViews =  UsedCarListing::updateViewTracker($action, $id);
		
		header("Location: sellerDashBoard.php");
	}
}
?>
