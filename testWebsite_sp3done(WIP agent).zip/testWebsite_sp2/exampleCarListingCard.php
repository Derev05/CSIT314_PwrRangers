<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Listing</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
	<script>
	$('document').ready(function(){
		$('#navbar').load("navbar.php");
	});
	</script>
    <style>
        .price {
            color: red;
            font-weight: bold;
        }
        .price-monthly {
            color: #888;
            font-size: 0.9em;
        }
        .car-info p {
            margin-bottom: 5px;
            font-size: 0.9em;
        }
		 /* Styling for the counter box in the bottom-right corner */
        .counters {
            position: absolute;
            bottom: 10px;
            right: 15px;
            display: flex;
            gap: 10px;
            align-items: center;
            font-size: 0.9em;
            color: #555;
        }
        .card {
            position: relative;
            cursor: pointer;
        }
    </style>
</head>
<body>
<div id="navbar"></div>

<!-- No tracking -->
<div class="container mt-4">
<a href="carListing.php?id=${item.id}" class="card-link">
	<div class="card">
		<div class="row g-0">
			<!-- Car Image -->
			<div class="col-md-2">
				<img src="${item.imagePath}" class="img-fluid rounded-start" alt="Car image">
			</div>
			<!-- Car Details -->
			<div class="col-md-10">
				<div class="card-body">
					<h5 class="card-title">${item.car_name}</h5>
					<p class="price" id="price">${item.price}</p>
					<div class="row">
						<div class="col-6 col-md-4 car-info">
							<p><i class="bi bi-calendar3"></i> Registered: ${item.regDate}</p>
							<p><i class="bi bi-person"></i> ${item.noOfOwners} Owners</p>
						</div>
					</div>
					<p class="mt-3">${item.description}</p>
					<!-- View and shortlist counters -->
					<p class="view-count">Views: ${item.noOfViews}</p>
					<p class="shortlist-count">Shortlists: ${item.noOfShortlists}</p>
					<div class="counters">
						<button class="btn btn-primary btn-sm edit-listing" data-id="${item.id}">Edit</button>
						<button class="btn btn-danger btn-sm delete-listing" data-id="${item.id}">Delete</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</a>
</div>

<!-- Tracking views only -->
<div class="container mt-4">
<a href="carListing.php?id=${item.id}" class="card-link">
	<div class="card">
		<div class="row g-0">
			<!-- Car Image -->
			<div class="col-md-2">
				<img src="${item.imagePath}" class="img-fluid rounded-start" alt="Car image">
			</div>
			<!-- Car Details -->
			<div class="col-md-10">
				<div class="card-body">
					<h5 class="card-title">${item.car_name}</h5>
					<p class="price" id="price">${item.price}</p>
					<div class="row">
						<div class="col-6 col-md-4 car-info">
							<p><i class="bi bi-calendar3"></i> Registered: ${item.regDate}</p>
							<p><i class="bi bi-person"></i> ${item.noOfOwners} Owners</p>
						</div>
					</div>
					<p class="mt-3">${item.description}</p>
					<!-- View and shortlist counters -->
					<p class="view-count">Views: ${item.noOfViews}</p>
					<div class="counters">
						<form id="trackViews" action="TrackViewsController.php" method="GET">
							<input type="hidden" name="action" value="untrack">
							<input type="hidden" name="viewsListingId" id="viewsListingId" value="${item.id}">
							<button type="submit" class="btn btn-danger">Untrack views on this listing</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</a>
</div>

<!-- Tracking shortlists only -->
<div class="container mt-4">
<a href="carListing.php?id=${item.id}" class="card-link">
	<div class="card">
		<div class="row g-0">
			<!-- Car Image -->
			<div class="col-md-2">
				<img src="${item.imagePath}" class="img-fluid rounded-start" alt="Car image">
			</div>
			<!-- Car Details -->
			<div class="col-md-10">
				<div class="card-body">
					<h5 class="card-title">${item.car_name}</h5>
					<p class="price" id="price">${item.price}</p>
					<div class="row">
						<div class="col-6 col-md-4 car-info">
							<p><i class="bi bi-calendar3"></i> Registered: ${item.regDate}</p>
							<p><i class="bi bi-person"></i> ${item.noOfOwners} Owners</p>
						</div>
					</div>
					<p class="mt-3">${item.description}</p>
					<!-- View and shortlist counters -->
					<p class="shortlist-count">Shortlists: ${item.noOfShortlists}</p>
					<div class="counters">
						<form id="trackShortlists" action="TrackShortlistsController.php" method="GET">
							<input type="hidden" name="action" value="untrack">
							<input type="hidden" name="shortListingId" id="shortListingId" value="${item.id}">
							<button type="submit" class="btn btn-danger">Untrack shortlists on this listing</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</a>
</div>



<!-- Bootstrap JS and Icons -->


</body>
</html>
