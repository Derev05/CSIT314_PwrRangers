<?php
require_once 'UsedCarListing.php';
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD'] === "GET") {
	TrackBothStatsCarListingFetchController::searchTrackedCarListingsBoth(isset($_GET['query']) ? $_GET['query'] : '', $_GET['username']);
}

class TrackBothStatsCarListingFetchController {	
	public static function searchTrackedCarListingsBoth($query, $sellerName) {
		$listings = UsedCarListing::searchTrackedCarListingsBoth($query, $sellerName);

		echo json_encode($listings);
	}
}
?>
