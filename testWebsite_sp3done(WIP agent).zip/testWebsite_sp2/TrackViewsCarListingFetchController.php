<?php
require_once 'UsedCarListing.php';
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD'] === "GET") {
	TrackViewsCarListingFetchController::searchTrackedCarListingsViews(isset($_GET['query']) ? $_GET['query'] : '', $_GET['username']);
}

class TrackViewsCarListingFetchController {	
	public static function searchTrackedCarListingsViews($query, $sellerName) {
		$listings = UsedCarListing::searchTrackedCarListingsViews($query, $sellerName);

		echo json_encode($listings);
	}
}
?>
