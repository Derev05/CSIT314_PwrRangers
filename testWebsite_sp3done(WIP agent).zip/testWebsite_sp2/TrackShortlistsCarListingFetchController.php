<?php
require_once 'UsedCarListing.php';
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD'] === "GET") {
	TrackShortlistsCarListingFetchController::searchTrackedCarListingsShortlists(isset($_GET['query']) ? $_GET['query'] : '', $_GET['username']);
}

class TrackShortlistsCarListingFetchController {	
	public static function searchTrackedCarListingsShortlists($query, $sellerName) {
		$listings = UsedCarListing::searchTrackedCarListingsShortlists($query, $sellerName);

		echo json_encode($listings);
	}
}
?>
