<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- 	<link rel="stylesheet" href="assets/css/style.css">-->	
	<link rel="stylesheet" href="assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
	<script src="assets/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
	<script>
	$('document').ready(function(){
		$('#navbar').load("navbar.php");
	});
	
	function showPW(){
	var pw = document.getElementById("pw");
	if(pw.type === "password") {
		pw.type = "text";
		} else {
		pw.type = "password";
		}
	}
    

	</script>
	<style>
        /* Center the card both horizontally and vertically */
        body {
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f8f9fa; /* Optional: Set a background color */
        }
        .login {
            width: 300px;
			margin-left: 50%; 
			margin-top:15%;
            padding: 20px;
            background: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
    </style>
</head>
<body>
	<div id="navbar"></div>
	<div class="card login bg-primary-subtle">
		<form action="LoginAuthCtr.php" method="POST">
		<div class="card-header text-center fw-bold fs-3" >
			<h3>Member Login</h3>
		</div>
		<div id="message-box" class="message-box">
		<?php 
			if(isset($_SESSION['message'])) {
				echo $_SESSION['message'];
				$_SESSION['message'] = NULL;
			}
		?>
		</div>
		<div class="mb-3">
			<input type="username" class="form-control" id="username" placeholder="Username" name="username" required>
		</div>
		<div class="mb-3">
			<input type="password" class="form-control" id="pw" placeholder="Password" name="password" required>
		</div>
		<div class="form-check">
			<input class="form-check-input" type="checkbox" value="" id="pwCheckbox"  onclick="showPW()">
			<label class="form-check-label" for="pwCheckbox">
			  Show Password
			</label>
		  </div>
		  <div class="form-check">
			<!--<input class="form-check-input" type="checkbox" value="" name="remember" id="rmbrCheckbox"  checked="checked" >
			<label class="form-check-label" for="pwCheckbox">
			  Remember Me
			</label>!-->
		  </div>
		  <div class="mb-3">
			<span class="psw"><a href="#">Forgot password?</a></span>
		</div>
		<div class="d-grid mb-3">
			<button class="btn btn-primary " type="submit">Login</button>	
			</div>
		</form>
	</div>
</body>
</html>