<?php
class UsedCarListing {
	// Static method to handle database connection
    private static function connectDB() {
        $conn = new mysqli("localhost", "root", "", "cars");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }
	
	public static function searchListingsforSeller($query, $sellerName) {
        $conn = self::connectDB();
        $sql = "SELECT * FROM carlistings WHERE (car_name LIKE ? OR vehType LIKE ?) AND seller_name = ?";
        $stmt = $conn->prepare($sql);
        $likeQuery = "%" . $query . "%";
        $stmt->bind_param("sss", $likeQuery, $likeQuery, $sellerName);
        $stmt->execute();
        $result = $stmt->get_result();
        $listings = [];
        while ($row = $result->fetch_assoc()) {
            $listings[] = $row;
        }
        return $listings;
    }
	
	public static function getListingbyId($id) {
        $conn = self::connectDB();
        $query = "SELECT * FROM carlistings WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $listingInfo = [];
        while ($row = $result->fetch_assoc()) {
            $listingInfo[] = $row;
        }
        return $listingInfo;
    }
}