<?php
session_start();
require_once 'UserAccount.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Call the controller to create the user
    $createUserResponse = UserCreationController::createUser(
        $_POST['username'],
        $_POST['password'],
        $_POST['contactno'],
        $_POST['email'],
        $_POST['dob'],
        $_POST['role'],
        isset($_POST['isSuspended']) ? $_POST['isSuspended'] : '0'
    );

    // Return JSON response
    echo json_encode($createUserResponse);
}

class UserCreationController {
    
    public static function createUser($username, $password, $contactno, $email, $dob, $role, $is_suspended) {
        // Check if the username already exists
        if (UserAccount::usernameExists($username)) {
            return ['success' => false, 'message' => 'Username already exists.'];
        }

        // Data array for creating user information
        $data = [
            'username' => $username,
            'password' => $password,
            'contactno' => $contactno,
            'email' => $email,
            'dob' => $dob,
            'role' => $role,
            'is_suspended' => $is_suspended === '1' ? 1 : 0 // Convert to integer
        ];

        // Call createUser method in UserAccount.php to add the new user
        $result = UserAccount::createUser($data);

        if ($result) {
            $_SESSION['message'] = 'User created successfully.';
            return ['success' => true, 'message' => 'User created successfully.'];
        } else {
            $_SESSION['message'] = 'Failed to create user.';
            return ['success' => false, 'message' => 'Failed to create user.'];
        }
    }
}
