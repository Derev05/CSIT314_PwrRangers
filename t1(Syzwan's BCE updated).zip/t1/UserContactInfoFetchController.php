<?php
require_once 'UserAccount.php';
header('Content-Type: application/json');


if($_SERVER['REQUEST_METHOD'] === "GET") {
	UserContactInfoFetchController::getContactInfo($_GET['username']);
}

class UserContactInfoFetchController {
	public static function getContactInfo($username) {
		$userInfo = UserAccount::getUserbyUsername($username);
		
		echo json_encode($userInfo);
	}
}