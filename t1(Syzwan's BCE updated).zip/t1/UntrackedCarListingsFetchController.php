<?php
require_once 'UsedCarListing.php';
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD'] === "GET") {
	UntrackedCarListingsFetchController::searchUntrackedCarListings(isset($_GET['query']) ? $_GET['query'] : '', $_GET['username']);
}

class UntrackedCarListingsFetchController {	
	public static function searchUntrackedCarListings($query, $sellerName) {
		$listings = UsedCarListing::searchUntrackedCarListings($query, $sellerName);

		echo json_encode($listings);
	}
}
?>
