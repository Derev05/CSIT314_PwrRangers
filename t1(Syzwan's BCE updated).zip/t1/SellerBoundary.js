document.addEventListener('DOMContentLoaded', () => {
    new SellerBoundary();
});

class SellerBoundary {
	constructor() {
		 this.init()
	}
	
	init() {
		this.loadTrackedListingsBoth()
		this.loadTrackedListingsShortlists()
		this.loadTrackedListingsViews()
		this.loadUntrackedCarListings()
		this.setupEventListeners()
	}
	
	loadTrackedListingsBoth(query = ' ') {
		fetch('TrackBothStatsCarListingFetchController.php?query=' + query + '&username=' + username)
		.then(response => response.json())
		.then(data => {
        const cardContainer = document.getElementById('trackBothStatsCarListings');
        cardContainer.innerHTML = ''; // Clear existing content

        data.forEach(item => {
            const card = document.createElement('div');
            card.className = 'container mt-4';
            card.innerHTML =`
			<a href="carListing.php?id=${item.id}" class="card-link">
			<div class="card">
				<div class="row g-0">
					<!-- Car Image -->
					<div class="col-md-2">
						<img src="${item.imagePath}" class="img-fluid rounded-start" alt="Car image">
					</div>
					<!-- Car Details -->
					<div class="col-md-10">
						<div class="card-body">
							<h5 class="card-title">${item.car_name}</h5>
							<p class="price" id="price">${item.price}</p>
							<div class="row">
								<div class="col-6 col-md-4 car-info">
									<p><i class="bi bi-calendar3"></i> Registered: ${item.regDate}</p>
									<p><i class="bi bi-person"></i> ${item.noOfOwners} Owners</p>
								</div>
							</div>
							<p class="mt-3">${item.description}</p>
							<!-- View and shortlist counters -->
							<p class="view-count">Views: ${item.noOfViews}</p>
							<p class="shortlist-count">Shortlists: ${item.noOfShortlists}</p>
							<div class="counters">
								<form id="trackViews" action="TrackViewsController.php" method="GET">
										<input type="hidden" name="action" value="untrack">
										<input type="hidden" name="viewsListingId" id="viewsListingId" value="${item.id}">
										<button type="submit" class="btn btn-danger">Untrack views on this listing</button>
									</form>
								<form id="trackShortlists" action="TrackShortlistsController.php" method="GET">
									<input type="hidden" name="action" value="untrack">
									<input type="hidden" name="shortListingId" id="shortListingId" value="${item.id}">
									<button type="submit" class="btn btn-danger">Untrack shortlists on this listing</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			</a>
		`;
		cardContainer.appendChild(card);
		});
	})
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
	}
	
	loadTrackedListingsShortlists(query = ' ') {
		fetch('TrackShortlistsCarListingFetchController.php?query=' + query + '&username=' + username)
		.then(response => response.json())
		.then(data => {
        const cardContainer = document.getElementById('trackShortlistsCarListings');
        cardContainer.innerHTML = ''; // Clear existing content

        data.forEach(item => {
            const card = document.createElement('div');
            card.className = 'container mt-4';
            card.innerHTML =`
			<a href="carListing.php?id=${item.id}" class="card-link">
			<div class="card">
				<div class="row g-0">
					<!-- Car Image -->
					<div class="col-md-2">
						<img src="${item.imagePath}" class="img-fluid rounded-start" alt="Car image">
					</div>
					<!-- Car Details -->
					<div class="col-md-10">
						<div class="card-body">
							<h5 class="card-title">${item.car_name}</h5>
							<p class="price" id="price">${item.price}</p>
							<div class="row">
								<div class="col-6 col-md-4 car-info">
									<p><i class="bi bi-calendar3"></i> Registered: ${item.regDate}</p>
									<p><i class="bi bi-person"></i> ${item.noOfOwners} Owners</p>
								</div>
							</div>
							<p class="mt-3">${item.description}</p>
							<!-- View and shortlist counters -->
							<p class="shortlist-count">Shortlists: ${item.noOfShortlists}</p>
							<div class="counters">
								<form id="trackViews" action="TrackViewsController.php" method="GET">
										<input type="hidden" name="action" value="track">
										<input type="hidden" name="viewsListingId" id="viewsListingId" value="${item.id}">
										<button type="submit" class="btn btn-success">Track views on this listing</button>
								</form>
								<form id="trackShortlists" action="TrackShortlistsController.php" method="GET">
									<input type="hidden" name="action" value="untrack">
									<input type="hidden" name="shortListingId" id="shortListingId" value="${item.id}">
									<button type="submit" class="btn btn-danger">Untrack shortlists on this listing</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			</a>
		`;
		cardContainer.appendChild(card);
		});
	})
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
	}
	
	
	loadTrackedListingsViews(query = ' '){
		fetch('TrackViewsCarListingFetchController.php?query=' + query + '&username=' + username)
		.then(response => response.json())
		.then(data => {
        const cardContainer = document.getElementById('trackViewsCarListings');
        cardContainer.innerHTML = ''; // Clear existing content

        data.forEach(item => {
            const card = document.createElement('div');
            card.className = 'container mt-4';
            card.innerHTML = `
                <a href="carListing.php?id=${item.id}" class="card-link">
				<div class="card">
					<div class="row g-0">
						<!-- Car Image -->
						<div class="col-md-2">
							<img src="${item.imagePath}" class="img-fluid rounded-start" alt="Car image">
						</div>
						<!-- Car Details -->
						<div class="col-md-10">
							<div class="card-body">
								<h5 class="card-title">${item.car_name}</h5>
								<p class="price" id="price">${item.price}</p>
								<div class="row">
									<div class="col-6 col-md-4 car-info">
										<p><i class="bi bi-calendar3"></i> Registered: ${item.regDate}</p>
										<p><i class="bi bi-person"></i> ${item.noOfOwners} Owners</p>
									</div>
								</div>
								<p class="mt-3">${item.description}</p>
								<!-- View and shortlist counters -->
								<p class="view-count">Views: ${item.noOfViews}</p>
								<div class="counters">
									<form id="trackViews" action="TrackViewsController.php" method="GET">
										<input type="hidden" name="action" value="untrack">
										<input type="hidden" name="viewsListingId" id="viewsListingId" value="${item.id}">
										<button type="submit" class="btn btn-danger">Untrack views on this listing</button>
									</form>
									<form id="trackShortlists" action="TrackShortlistsController.php" method="GET">
										<input type="hidden" name="action" value="track">
										<input type="hidden" name="shortListingId" id="shortListingId" value="${item.id}">
										<button type="submit" class="btn btn-success">Track shortlists on this listing</button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				</a>
            `;
            cardContainer.appendChild(card);
        });
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
	}
	
	loadUntrackedCarListings(query = ' ') {
		fetch('UntrackedCarListingsFetchController.php?query=' + query + '&username=' + username)
		.then(response => response.json())
		.then(data => {
        const cardContainer = document.getElementById('untrackedCarListings');
        cardContainer.innerHTML = ''; // Clear existing content

        data.forEach(item => {
            const card = document.createElement('div');
            card.className = 'container mt-4';
            card.innerHTML = `
                <a href="carListing.php?id=${item.id}" class="card-link">
                    <div class="card">
                        <div class="row g-0">
                            <!-- Car Image -->
                            <div class="col-md-2">
                                <img src="${item.imagePath}" class="img-fluid rounded-start" alt="Car image">
                            </div>
                            <!-- Car Details -->
                            <div class="col-md-10">
                                <div class="card-body">
                                    <h5 class="card-title">${item.car_name}</h5>
                                    <p class="price" id="price">${item.price}</p>
                                    <div class="row">
                                        <div class="col-6 col-md-4 car-info">
                                            <p><i class="bi bi-calendar3"></i> Registered: ${item.regDate}</p>
                                            <p><i class="bi bi-person"></i> ${item.noOfOwners} Owners</p>
                                        </div>
                                    </div>
                                    <p class="mt-3">${item.description}</p>
									<!-- View and shortlist counters -->
									<div class="counters">
									<form id="trackViews" action="TrackViewsController.php" method="GET">
										<input type="hidden" name="action" value="track">
										<input type="hidden" name="viewsListingId" id="viewsListingId" value="${item.id}">
										<button type="submit" class="btn btn-success">Track views on this listing</button>
									</form>
									<form id="trackShortlists" action="TrackShortlistsController.php" method="GET">
										<input type="hidden" name="action" value="track">
										<input type="hidden" name="shortListingId" id="shortListingId" value="${item.id}">
										<button type="submit" class="btn btn-success">Track shortlists on this listing</button>
									</form>
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            `;
            cardContainer.appendChild(card);
        });
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
  }
  
  setupEventListeners() {
	  document.querySelector('#searchCarListing').addEventListener('input', () => {
			this.loadTrackedListingsShortlists(document.querySelector('#searchCarListing').value);
			this.loadTrackedListingsViews(document.querySelector('#searchCarListing').value);
            this.loadCarListings(document.querySelector('#searchCarListing').value);
      });
  }
}