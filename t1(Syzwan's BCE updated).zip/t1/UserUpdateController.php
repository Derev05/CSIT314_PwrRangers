<?php
session_start();

require_once 'UserAccount.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Call the controller to update the user
    $updateUser = UserUpdateController::updateUser(
        $_POST['userId'],
        $_POST['username'],
        $_POST['password'],
        $_POST['contactno'],
        $_POST['email'],
        $_POST['dob'],
        $_POST['role'],
        $_POST['isSuspended']
    );

    // Return JSON response
    echo json_encode($updateUser);
}

class UserUpdateController {
    
    public static function updateUser($id, $username, $password, $contactno, $email, $dob, $role, $is_suspended) {
        // Data array for updating user information
        $data = [
            'id' => $id,
            'username' => $username,
            'password' => $password,
            'contactno' => $contactno,
            'email' => $email,
            'dob' => $dob,
            'role' => $role,
            'is_suspended' => $is_suspended
        ];

        // Update the user using UserAccount method without passing DB directly
        $result = UserAccount::updateUser($data);

        // Return JSON response based on result
        if ($result) {
            $_SESSION['message'] = 'User updated successfully.';
            return ['success' => true, 'message' => 'User updated successfully.'];
        } else {
            $_SESSION['message'] = 'Failed to update user.';
            return ['success' => false, 'message' => 'Failed to update user.'];
        }
    }
}
