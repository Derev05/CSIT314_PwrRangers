<?php
class UserAccount {
    // Static method to handle database connection
    private static function connectDB() {
        $conn = new mysqli("localhost", "root", "", "user_management");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }

    // Static method to create a new user account
  public static function createUser($data) {
    $conn = self::connectDB(); // Get the DB connection
    try {
        $query = "INSERT INTO users (username, password, contactno, email, dob, role, is_suspended)
                  VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($query);

        // Bind parameters
        $stmt->bind_param("ssssssi", 
            $data['username'], 
            $data['password'], 
            $data['contactno'], 
            $data['email'], 
            $data['dob'], 
            $data['role'], 
            $data['is_suspended']
        );

        // Execute insert statement
        return $stmt->execute();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        return false;
    } finally {
        $stmt->close(); // Close the statement
        $conn->close(); // Close the connection
    }
}



    // Static method to retrieve user by username and password (for login authentication)
    public static function loginAuth($username, $password) {
        $conn = self::connectDB();
        $query = "SELECT * FROM users WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    public static function getUserbyUsername($username) {
        $conn = self::connectDB();
        $query = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    // Static method to search users based on query
    public static function searchUsers($query) {
        $conn = self::connectDB();
        $sql = "SELECT * FROM users WHERE username LIKE ? OR email LIKE ?";
        $stmt = $conn->prepare($sql);
        $likeQuery = "%" . $query . "%";
        $stmt->bind_param("ss", $likeQuery, $likeQuery);
        $stmt->execute();
        $result = $stmt->get_result();
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        return $users;
    }

    public static function signUpUser($data) {
        $conn = self::connectDB(); 
        $query = "INSERT INTO users (username, password, contactno, email, dob, role)
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param(
            "ssssss",
            $data['username'],
            $data['password'],
            $data['contactno'],
            $data['email'],
            $data['dob'],
            $data['role']
        );

        return $stmt->execute();
    }

    // Static method to suspend a user account by ID
    public static function suspendUser($userId) {
        $conn = self::connectDB();
        $query = "UPDATE users SET is_suspended = 1 WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }

    // Static method to update a user account
    public static function updateUser($data) {
        $conn = self::connectDB(); // Get the DB connection
        try {
            $query = "UPDATE users SET 
                        username = ?, 
                        password = ?, 
                        contactno = ?, 
                        email = ?, 
                        dob = ?, 
                        role = ?, 
                        is_suspended = ? 
                      WHERE id = ?";
                      
            $stmt = $conn->prepare($query);

            // Bind parameters
            $stmt->bind_param("sssssssi", 
                $data['username'], 
                $data['password'], 
                $data['contactno'], 
                $data['email'], 
                $data['dob'], 
                $data['role'], 
                $data['is_suspended'], // Ensure is_suspended is treated as an integer
                $data['id'] // Ensure id is treated as an integer
            );

            // Execute update
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
            return false;
        } finally {
            $stmt->close(); // Close the statement
            $conn->close(); // Close the connection
        }
    }

    // Static method to delete a user account
    public static function deleteUser($userId) {
        $conn = self::connectDB();
        $query = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }


    public static function usernameExists($username) {
    $conn = self::connectDB(); // Get the DB connection
    try {
        $query = "SELECT COUNT(*) FROM users WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        return $count > 0; // Return true if the username exists
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        return false;
    } finally {
        $stmt->close(); // Close the statement
        $conn->close(); // Close the connection
    }
}

    // Static method to get user by ID
    public static function getUserById($userId) {
    $conn = self::connectDB();
    try {
        $query = "SELECT * FROM users WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        return null;
    }
}



    // Static getters for properties, if needed, could be defined here based on use case
}
?>
