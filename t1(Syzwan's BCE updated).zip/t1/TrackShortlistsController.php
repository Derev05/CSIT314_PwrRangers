<?php
require_once 'UsedCarListing.php';
header('Content-Type: application/json');


if($_SERVER['REQUEST_METHOD'] === "GET") {
	TrackShortlistsController::updateShortlistTracker($_GET['action'], $_GET['shortListingId']);
}

class TrackShortlistsController {
	
	public static function updateShortlistTracker($action, $id) {		
		$trackViews =  UsedCarListing::updateShortlistTracker($action, $id);
		
		header("Location: sellerDashBoard.php");
	}
}
?>
