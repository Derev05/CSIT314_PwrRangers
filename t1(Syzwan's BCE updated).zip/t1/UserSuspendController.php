<?php
session_start();
require_once 'UserAccount.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if user ID is provided
    if (isset($_POST['id'])) {
        $userId = $_POST['id'];

        // Call the controller to suspend the user
        $suspendResponse = UserSuspendController::suspendUser($userId);

        // Return JSON response
        echo json_encode($suspendResponse);
    } else {
        echo json_encode(['success' => false, 'message' => 'No user ID provided.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}

class UserSuspendController {
    
    public static function suspendUser($userId) {
        // First, get the current status of the user
        $user = UserAccount::getUserById($userId);
        
        if ($user) {
            if ($user['is_suspended'] == 1) {
                // The user is already suspended
                return ['success' => false, 'message' => 'Account has already been suspended.'];
            } else {
                // Proceed to suspend the account
                $result = UserAccount::suspendUser($userId);
                
                if ($result) {
                    return ['success' => true, 'message' => 'User suspended successfully.'];
                } else {
                    return ['success' => false, 'message' => 'Failed to suspend user.'];
                }
            }
        } else {
            return ['success' => false, 'message' => 'User not found.'];
        }
    }
}
