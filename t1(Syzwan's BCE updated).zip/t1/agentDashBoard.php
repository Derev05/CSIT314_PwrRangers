<?php
session_start();

function logout() {
	session_unset(); // Unset all session variables
	session_destroy(); // Destroy the session
	header("Location: index.php");
	exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['logout'])) {
	logout();
};

// Prevent caching to avoid "back" button issue after logout
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
	
	<style>
        .price {
            color: red;
            font-weight: bold;
        }
        .price-monthly {
            color: #888;
            font-size: 0.9em;
        }
        .car-info p {
            margin-bottom: 5px;
            font-size: 0.9em;
        }
		 /* Styling for the counter box in the bottom-right corner */
        .counters {
            position: absolute;
            bottom: 10px;
            right: 15px;
            display: flex;
            gap: 10px;
            align-items: center;
            font-size: 0.9em;
            color: #555;
        }
        .card {
            position: relative;
            cursor: pointer;
        }
    </style>

	<!-- DataTables CSS -->
	<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

	<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
	<script src="assets/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

	<!-- DataTables JS -->
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

	<title>Buyer Dashboard</title>
</head>
<body>
	<!-- Navbar Code (Updated with image link for Home) -->
	<nav class="py-2 bg-primary-subtle border-bottom">
		<div class="container d-flex flex-wrap justify-content-between">
			<ul class="nav me-auto">
				<li class="nav-item">
					<a href="index.php" class="nav-link">Home</a>
				</li>
			</ul>
			<div class="nav">
			<?php		
				echo '<a class="nav-link link-dark px-2">'.$_SESSION['username'].'</a>';
			?>
				<form action="navbar.php" method="POST">
				<button type="submit" name="logout" class="nav-link link-dark px-2">
						Log Out
				</button>
				</form>
			</div>
		</div>
	</nav>

	<!-- Car Listing Search Section -->
	<div class="container mt-4">
		<div class="d-flex justify-content-between mb-3">
			<h4>Your Car Listings</h4>
			<button class="btn btn-success" id="addCarListingBtn" data-bs-toggle="modal" data-bs-target="#addCarListingModal">+ Add Car Listing</button>
		</div>
		<input type="search" id="searchCarListing" class="form-control" placeholder="Search Car Listing" name="query" required>
		<table class="table">
			<tbody id="listOfcarListings">
				<!-- Car listing data will be loaded here via JavaScript -->
			</tbody>
		</table>
	</div>
	
	<!-- Add/Edit Car Listing Modal -->
	<div class="modal fade" id="addCarListingModal" tabindex="-1" aria-labelledby="addCarListingModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="addCarListingModalLabel">Add Info</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<form id="addCarListingForm" method="POST">
						<input type="hidden" id="listingId" name="listingId"> <!-- For storing user ID when editing -->
						<div class="mb-3">
							<label for="sellerName" class="form-label">Seller Name</label>
							<input type="text" class="form-control" id="seller_name" name="seller_name" required minlength="4">
							<div class="invalid-feedback">Username must be at least 4 characters long.</div>
						</div>
						<div class="mb-3">
							<label for="car_name" class="form-label">Car Name</label>
							<input type="text" class="form-control" id="car_name" name="car_name" required>
							<div class="invalid-feedback">Please provide the name of the car.</div>
						</div>
						<div class="mb-3">
							<label for="plate_no" class="form-label">Plate Number</label>
							<input type="text" class="form-control" id="plate_no" name="plate_no" required>
							<div class="invalid-feedback">Please provide a plate number.</div>
						</div>

						<div class="mb-3">
							<label for="noOfOwners" class="form-label">No. of Owners</label>
							<input type="text" class="form-control" id="noOfOwners" name="noOfOwners" required>
							<div class="invalid-feedback">Please provide a valid number of previous owners.</div>
						</div>
						<div class="mb-3">
							<label for="regDate" class="form-label">Registration Date</label>
							<input type="date" class="form-control" id="regDate" name="regDate" required>
							<div class="invalid-feedback">Please provide a valid registration date.</div>
						</div>
						<div class="mb-3">
							<label for="vehType" class="form-label">Vehicle Type</label>
							<input type="text" class="form-control" id="vehType" name="vehType" required>
							<div class="invalid-feedback">Please provide a valid vehicle type.</div>
						</div>
						<div class="mb-3">
							<label for="vehType" class="form-label">Description</label>
							<textarea id="vehType" name="vehType" rows="5" cols="50" required></textarea>
							<div class="invalid-feedback">Please provide a description of the car.</div>
						</div>
						<div class="mb-3">
							<label for="image" class="form-label">Image</label>
							<input type="file" id="imageInput" name="image" required>
							<div class="invalid-feedback">Please provide an accompanying image of the car.</div>
						</div>
						<button type="submit" class="btn btn-primary" id="saveCarListingBtn">Save User</button>						
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<!-- JavaScript to handle form submission and BCE classes -->
	<script>
		var username = <?php echo json_encode($_SESSION['username']); ?>
	</script>
	<script src="AgentCarListingBoundary.js"></script>	
</body>
</html>
