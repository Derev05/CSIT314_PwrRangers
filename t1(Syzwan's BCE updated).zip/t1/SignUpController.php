<?php
session_start();
require_once 'UserAccount.php';

// Handle form submission directly in the controller
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $signUp = SignUpController::signUpUser($_POST);
}

class SignUpController {

    public static function signUpUser($postData) {
        // Collect data
        $username = $postData['username'];

        // Check if the username already exists
        if (UserAccount::usernameExists($username)) {
            $_SESSION['message'] = 'Username already exists.';
            header('Location: signUp.php'); // Redirect back to sign-up page
            exit();
        }

        // If not exists, collect other data and hash password
        $data = [
            'username' => $username,
            'password' => $postData['password'], 
            'contactno' => $postData['contactno'],
            'email' => $postData['email'],
            'dob' => $postData['dob'],
            'role' => $postData['role'],
            'is_suspended' => 0 // Default to not suspended
        ];

        // Create UserAccount instance and call createUser method
        $user = new UserAccount();
        $result = $user->signUpUser($data);

        // Provide feedback and redirect based on the result
        if ($result) {
            $_SESSION['message'] = 'User created successfully.';
            header('Location: LoginPage.php'); // Redirect to login page
        } else {
            $_SESSION['message'] = 'Failed to create user.';
            header('Location: signUp.php'); // Redirect back to sign-up page on failure
        }
        exit();
    }
}
?>
