<?php
session_start();
require_once 'UserAccount.php';
header('Content-Type: application/json');

if (isset($_GET['id'])) {
    $userId = $_GET['id'];

    // Call the controller to fetch the user
    $fetchResponse = UserFetchController::getUserById($userId);

    // Return JSON response
    echo json_encode($fetchResponse);
} else {
    // Return a message if no user ID is provided
    echo json_encode(['success' => false, 'message' => 'No user ID provided.']);
}

class UserFetchController {
    
    public static function getUserById($userId) {
        // Call the method from UserAccount to fetch the user
        $user = UserAccount::getUserById($userId);

        if ($user) {
            // Return user data
            return ['success' => true, 'data' => $user];
        } else {
            // Return a message if the user is not found
            return ['success' => false, 'message' => 'User not found.'];
        }
    }
}
